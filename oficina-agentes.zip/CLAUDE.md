# Proyecto: Dashboard demográfico de Ciudad Juárez

Dashboard web de un solo archivo (`index.html`) con datos del Censo INEGI 2020 por manzana de Ciudad Juárez.
Autor: Ricardo Ponce Cruz (estudiante de Diseño Urbano y del Paisaje, UACJ).
Publicado en GitHub Pages: https://ponceurbano.github.io/dashboard-censo-juarez/

## Técnica
- MapLibre GL 3.6.2 y Turf.js 6, cargados por CDN. Sin servidor ni compilación.
- Datos en `manzanas_censo_tema1.geojson`, junto a `index.html`.
- Todo en longitud/latitud (EPSG:4326).
- GitHub rechaza archivos de más de 100 MB. Cada capa nueva debe pesar mucho menos (meta: menos de 30 MB).

## Reglas de trabajo
- Responde en español.
- No inventes fuentes, URLs ni cifras. Si no puedes verificar algo, escribe "NO VERIFICADO".
- Cada capa nueva lleva fuente oficial, fecha, licencia o términos de uso y créditos. Los créditos se agregan al modal "Fuente y Créditos" de `index.html`.
- Antes de modificar `index.html` o `manzanas_censo_tema1.geojson`, haz una copia de respaldo (`*.respaldo.*`) y pide confirmación a Ricardo.
- No hagas `git commit` ni `git push`: eso lo hace Ricardo.
- No abras archivos `.geojson` completos: pesan mucho y gastan tokens. Usa `head`, `wc` o un script de Python para ver su estructura y resumirla.
- Los cálculos por radio son propios y no oficiales; se conserva el aviso legal del dashboard.

## Flujo de la oficina
1. `investigador-datos` busca y documenta fuentes en `investigacion/`.
2. Ricardo elige qué capas quiere.
3. `preparador-capas` las convierte a GeoJSON ligero en `capas/` y documenta el proceso en `capas/LEEME.md`.
4. `revisor` verifica y entrega un dictamen.
5. Solo después se integran al dashboard.
